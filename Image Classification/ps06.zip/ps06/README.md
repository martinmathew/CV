## Problem Set 6: Image Classification (Faces)

### Description

In this problem set you will be implementing face recognition using PCA, (Ada)Boosting, and the Viola-Jones algorithm.

### Instructions

See this assignment's Piazza post.