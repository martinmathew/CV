# Input images

Download the input images from these links:

* [circle](https://drive.google.com/open?id=0B3OoaIl44KLHSFY5MV9UTGhxWlE)
* [walking](https://drive.google.com/open?id=0B3OoaIl44KLHUkRpMy1CN1FZeW8)
* [pres_debate](https://drive.google.com/open?id=0B3OoaIl44KLHZHM2dmgzdXF4ZXc)
* [pres_debate_noisy](https://drive.google.com/open?id=0B3OoaIl44KLHWkY1U1VNSDZ4Zmc)
* [pedestrians](https://drive.google.com/open?id=0B3OoaIl44KLHbkZQSVZMR2pobGc)
* [TUD-Campus](https://drive.google.com/open?id=0B3OoaIl44KLHQ2pYTkFJQmhMOHM)
* [follow](https://drive.google.com/open?id=0B3OoaIl44KLHQ2cxYWVHcVYyVlU)
* [input_test](https://drive.google.com/open?id=0B0HPhvopISXsNXJhNnhNOUpEcXc)

Unzip each file and place each directory in this folder.