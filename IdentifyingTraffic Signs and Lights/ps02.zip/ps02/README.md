# Problem Set 2: Traffic Signs and Lights

## Description

Problem Set 2 is aimed at introducing basic building blocks of image processing.  Key areas that we wish to see you implement are: loading and manipulating images, producing some valued output of images, and comprehension of the structural and semantic aspects of what makes an image.  Relevant Lectures include 1-2 on Udacity.

## Instructions

See this assignment's google doc and piazza post.