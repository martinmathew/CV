## Problem Set 3: Introduction to AR

### Description

Problem Set 3 introduces the idea behind Augmented Reality, using concepts that you will learn in modules 3A-3D and 4A-4C: Projective geometry, Corner detection, Perspective imaging, and Homographies, respectively.

Additionally, you will also learn how to read from a video, process each video frame by identifying important features, insert images within images, and assemble a video from a sequence of frames.

### Instructions

See this assignment's google doc and piazza post.